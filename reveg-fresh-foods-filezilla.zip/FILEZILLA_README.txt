========================================================================
RevEg Fresh Foods - FileZilla / Apache PHP Hosting Deployment Guide
========================================================================

This package is 100% ready for Apache PHP hosting (Hostinger, cPanel, GoDaddy,
Namecheap, LiteSpeed, VPS, etc.). No Node.js, npm, Vite, or Bun is needed.

------------------------------------------------------------------------
DEPLOYMENT INSTRUCTIONS (STEP BY STEP)
------------------------------------------------------------------------

Option A: Root Domain (e.g., https://example.com/)
1. Open FileZilla and connect to your hosting server.
2. Navigate to your website root folder: /public_html/
3. Extract and upload all files from this ZIP directly into /public_html/
   - index.html
   - assets/
   - api/ (all PHP API endpoints: products, hero, inquiries, etc.)
   - uploads/ (hero/ and products/ image folders)
   - data/ (db.json, hero.json, inquiries.json)
   - .htaccess
   - reveg-logo.svg
4. Ensure folder permissions:
   - /uploads/ and /uploads/products/, /uploads/hero/ should be chmod 755 (or 775)
   - /data/ should be chmod 755 (or 775)
5. Visit your domain in the browser. The website and Admin Dashboard are live!

Option B: Subfolder / Subdirectory (e.g., /public_html/site2/)
1. Open FileZilla and navigate to: /public_html/site2/
2. Upload all files from this ZIP directly into /public_html/site2/
3. All asset paths and API endpoints are relative, so it works out of the box
   at: https://yourdomain.com/site2/ and https://yourdomain.com/site2/admin!

------------------------------------------------------------------------
DYNAMIC PRODUCT IMAGE & CATALOGUE MANAGEMENT
------------------------------------------------------------------------
- Navigate to /admin (e.g., https://yourdomain.com/admin or https://yourdomain.com/site2/admin)
- Log in to the Admin Dashboard (default: admin / admin123)
- Click "Products Catalogue" in the sidebar navigation
- Click "Edit" on any product (Besan Ladoo, Motichoor Ladoo, Chakli, Shankarpali, etc.)
- Use "Upload from Device" or "Replace Image" to select a new product image (JPG, PNG, WEBP)
- Or click "Delete / Reset Image" to remove the current image
- Preview the image immediately in real-time
- Click "Save Changes" / "Add Product"
- The new image is stored dynamically in uploads/products/ and saved in data/db.json
- The new image automatically updates everywhere that product is displayed across the customer website!

------------------------------------------------------------------------
DYNAMIC HERO IMAGE MANAGEMENT
------------------------------------------------------------------------
- In Admin Dashboard, open "Hero Image & Settings"
- Click "Upload Image" or replace existing hero image
- The image automatically updates on the live frontend Hero banner without editing any code!
========================================================================
