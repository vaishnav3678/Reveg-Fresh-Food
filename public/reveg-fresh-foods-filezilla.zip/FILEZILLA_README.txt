========================================================================
RevEg Fresh Foods - FileZilla / Apache PHP Hosting Deployment Guide
========================================================================

This package is 100% ready for Apache PHP hosting (Hostinger, cPanel, GoDaddy,
Namecheap, LiteSpeed, VPS, etc.). No Node.js, npm, Vite, or Bun is needed.

------------------------------------------------------------------------
DEPLOYMENT INSTRUCTIONS (STEP BY STEP)
------------------------------------------------------------------------

Option A: Root Domain (e.g., https://example.com/)
1. Open FileZilla and connect to your hosting server.
2. Navigate to your website root folder: /public_html/
3. Extract and upload all files from this ZIP directly into /public_html/
   - index.html
   - assets/
   - api/ (upload-hero.php, hero.php, public-content.php, inquiries.php)
   - uploads/hero/ (.htaccess)
   - data/ (hero.json, db.json)
   - .htaccess
   - reveg-logo.svg
4. Ensure folder permissions:
   - /uploads/ and /uploads/hero/ should be chmod 755 (or 775)
   - /data/ should be chmod 755 (or 775)
5. Visit your domain in the browser. The website and Admin Dashboard are live!

Option B: Subfolder / Subdirectory (e.g., /public_html/site2/)
1. Open FileZilla and navigate to: /public_html/site2/
2. Upload all files from this ZIP directly into /public_html/site2/
3. All asset paths and API endpoints are relative, so it works out of the box
   at: https://yourdomain.com/site2/ and https://yourdomain.com/site2/admin!

------------------------------------------------------------------------
HERO IMAGE MANAGEMENT
------------------------------------------------------------------------
- Navigate to /admin (e.g., https://yourdomain.com/admin or https://yourdomain.com/site2/admin)
- Log in to the Admin Dashboard (default: admin / admin123 or your configured password)
- Open "Hero Image Management & Hero Settings"
- Click "Upload New Hero Image" or drag & drop (JPG, JPEG, PNG, WEBP)
- Preview the image before saving
- Click "Upload & Save as Hero Image"
- The image is saved dynamically in /uploads/hero/ and appears instantly on the live website!
========================================================================
