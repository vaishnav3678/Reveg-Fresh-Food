var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path2 = __toESM(require("path"), 1);
var import_fs2 = __toESM(require("fs"), 1);
var import_bcryptjs2 = __toESM(require("bcryptjs"), 1);
var import_multer = __toESM(require("multer"), 1);
var import_vite = require("vite");
var import_supabase_js = require("@supabase/supabase-js");

// src/server/db.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var import_bcryptjs = __toESM(require("bcryptjs"), 1);
var DATA_DIR = import_path.default.join(process.cwd(), "data");
var DB_FILE = import_path.default.join(DATA_DIR, "db.json");
if (!import_fs.default.existsSync(DATA_DIR)) {
  import_fs.default.mkdirSync(DATA_DIR, { recursive: true });
}
var getDefaultDatabase = () => {
  const salt = import_bcryptjs.default.genSaltSync(10);
  const defaultPasswordHash = import_bcryptjs.default.hashSync("admin123", salt);
  return {
    users: [
      {
        id: "usr_admin",
        username: "admin",
        email: "revegfreshfoods@gmail.com",
        passwordHash: defaultPasswordHash,
        name: "RevEg Admin",
        role: "admin",
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      }
    ],
    sessions: {},
    settings: {
      siteName: "RevEg Fresh Foods",
      tagline: "Traditional Sweets, Festive Faral & Namkeen",
      logoUrl: "/reveg-logo.svg",
      faviconUrl: "/reveg-logo.svg",
      phone: "+91 94033 58033",
      whatsappNumber: "919403358033",
      whatsappDisplay: "+91 94033 58033",
      email: "revegfreshfoods@gmail.com",
      address: "Maharashtra, India",
      kitchenLocation: "Freshly Prepared & Dispatched in Maharashtra, India",
      businessHours: "Monday - Sunday: 8:00 AM - 9:00 PM",
      googleMapsUrl: "https://maps.google.com/?q=Maharashtra,India",
      socialLinks: {
        facebook: "https://facebook.com",
        instagram: "https://instagram.com",
        youtube: "https://youtube.com"
      },
      copyrightText: "\xA9 2026 RevEg Fresh Foods. All Rights Reserved. Crafted with traditional purity & homemade taste.",
      enableFloatingWhatsApp: true,
      defaultWhatsAppMessage: "Hello RevEg Fresh Foods, I would like to enquire about your products. Please share the available items, festive specials, and price list.",
      whatsappButtonText: "Order on WhatsApp"
    },
    theme: {
      primaryColor: "#0D5B29",
      primaryDark: "#083E1B",
      primaryLight: "#13753D",
      orangeColor: "#E8590C",
      orangeHover: "#CC4B04",
      yellowColor: "#F5A800",
      creamBg: "#FAF8F2",
      cardBg: "#FFFFFF",
      textColor: "#11311D",
      fontHeading: "Cinzel",
      fontBody: "Plus Jakarta Sans"
    },
    seo: {
      title: "RevEg Fresh Foods | Traditional Sweets, Faral & Namkeen",
      description: "Discover delicious traditional Indian sweets, festive faral, Diwali specials, crispy namkeen and custom gift boxes from RevEg Fresh Foods. Enquire and order easily on WhatsApp at +91 94033 58033.",
      keywords: "RevEg Fresh Foods, Indian Sweets, Diwali Faral, Besan Ladoo, Chakli, Shankarpali, Karanji, Poha Chivda, Kaju Katli, Gulab Jamun, Maharashtra sweets",
      ogTitle: "RevEg Fresh Foods | Traditional Sweets, Faral & Namkeen",
      ogDescription: "Authentic traditional Indian sweets, festive faral favourites, and crispy namkeen made fresh with pure ingredients.",
      ogImage: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=1200&auto=format&fit=crop&q=80",
      favicon: "/reveg-logo.svg"
    },
    sections: [
      { id: "hero", name: "Hero Banner", badge: "Authentic Heritage", title: "Traditional Flavours & Fresh Sweets", subtitle: "Crafted with purity & homemade care", enabled: true, sortOrder: 1 },
      { id: "festive-specials", name: "Festive Faral & Specials", badge: "Diwali & Festival Season", title: "Festive Faral & Sweets Collection", subtitle: "Celebrate every auspicious occasion with handcrafted delicacies", enabled: true, sortOrder: 2 },
      { id: "products", name: "Product Catalog", badge: "Fresh Daily Batches", title: "Our Authentic Product Catalog", subtitle: "Explore our wide array of traditional sweets, festive faral and crunchy namkeen", enabled: true, sortOrder: 3 },
      { id: "gift-boxes", name: "Custom Gift Box Builder", badge: "Personalized Gifting", title: "Build Your Custom Celebration Box", subtitle: "Handpick assorted sweets and faral for a memorable gift", enabled: true, sortOrder: 4 },
      { id: "about", name: "About RevEg Fresh Foods", badge: "Our Heritage & Passion", title: "The Story Behind RevEg Fresh Foods", subtitle: "Preserving golden culinary memories through pure ingredients and authentic techniques", enabled: true, sortOrder: 5 },
      { id: "why-choose-us", name: "Why Choose Us", badge: "Quality Assurance", title: "Why Families Choose RevEg Fresh Foods", subtitle: "Six pillars of our commitment to quality, taste and hygiene", enabled: true, sortOrder: 6 },
      { id: "gallery", name: "Photo Gallery", badge: "Visual Feast", title: "Culinary Traditions in Pictures", subtitle: "A glimpse of our appetizing sweets, crispy faral, and gift boxes", enabled: true, sortOrder: 7 },
      { id: "testimonials", name: "Customer Testimonials", badge: "Delighted Customers", title: "Loved by Families Everywhere", subtitle: "Real experiences from our valued customers", enabled: true, sortOrder: 8 },
      { id: "contact", name: "Contact & Inquiries", badge: "Direct Connect", title: "Get in Touch with RevEg Fresh Foods", subtitle: "Instant WhatsApp ordering, custom pack requests, and bulk catering enquiries", enabled: true, sortOrder: 9 }
    ],
    hero: {
      badge: "100% Vegetarian \u2022 Pure Desi Ghee & Fresh Ingredients",
      heading: "Authentic Taste of Tradition, Freshness You Can Trust",
      highlightWord: "Tradition",
      description: "Handcrafted traditional Indian sweets, festive faral delicacies, and savory namkeen made with heirloom recipes, pure ingredients, and zero compromise on hygiene.",
      primaryCtaText: "Order on WhatsApp",
      primaryCtaLink: "#contact",
      secondaryCtaText: "Diwali Faral Specials",
      secondaryCtaLink: "#festive-specials",
      heroImage: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=1000&auto=format&fit=crop&q=80",
      experienceYears: "Heritage Taste",
      purityGuarantee: "100% Pure & Fresh"
    },
    about: {
      badge: "Rooted in Heritage & Pure Taste",
      heading: "Crafted with Authentic Passion, Traditional Recipes & Purest Ingredients",
      description: "At RevEg Fresh Foods, we believe that food is not just nourishment\u2014it is a celebration of family, culture, and timeless festival memories.",
      storyP1: "Founded with a heartfelt vision to preserve the rich, authentic culinary traditions of India, RevEg Fresh Foods prepares traditional sweets, festive faral, and savory namkeen with the same love, cleanliness, and precision as our mothers and grandmothers did in heritage kitchens.",
      storyP2: "We strictly source superior grade pulses, cold-pressed oils, rich dry fruits, and pure desi ghee. Every batch is slow-roasted, perfectly seasoned, and freshly packed to guarantee crispness, authentic aroma, and unforgettable flavor in every bite.",
      mainImage: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=900&auto=format&fit=crop&q=80",
      subImage: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=600&auto=format&fit=crop&q=80",
      mission: "To deliver pure, hygienic, and authentically prepared Indian sweets and savories that bring joy and festive nostalgia to every celebration.",
      vision: "To be the most trusted and cherished household brand for traditional homemade taste, authentic festive faral, and celebratory gifting.",
      values: [
        "Pure & unadulterated raw ingredients",
        "Traditional small-batch slow roasting",
        "Strict hygiene and kitchen sanitization",
        "Eco-conscious and secure gift packaging",
        "Fast and dependable festive dispatch"
      ],
      stats: [
        { id: "stat_1", value: "100%", label: "Pure Veg & Fresh", subtext: "Prepared in hygienic kitchens" },
        { id: "stat_2", value: "15+", label: "Traditional Delicacies", subtext: "Ladoos, faral, namkeen & sweets" },
        { id: "stat_3", value: "5\u2605", label: "Festive Trust", subtext: "Loved for Diwali & family events" },
        { id: "stat_4", value: "Direct", label: "WhatsApp Ordering", subtext: "Instant batch pricing & delivery" }
      ]
    },
    products: [
      {
        id: "prod-besan-ladoo",
        name: "Besan Ladoo",
        category: "diwali",
        secondaryCategories: ["sweets"],
        description: "Golden roasted gram flour ladoos blended with pure desi ghee, fragrant green cardamom, and crunchy dry fruits.",
        detailedDescription: "Our signature festive delicacy prepared by slow-roasting coarse gram flour (besan) in generous pure desi ghee until rich golden brown, flavored with fresh ground cardamom, crunchy almonds, and cashews.",
        image: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=800&auto=format&fit=crop&q=80",
        isPopular: true,
        isFestiveSpecial: true,
        packSizes: ["250g", "500g", "1 kg", "2 kg"],
        tasteProfile: "Rich, aromatic, melt-in-mouth sweetness",
        ingredientsHighlight: ["Pure Desi Ghee", "Premium Gram Flour", "Cardamom", "Cashews & Almonds"],
        texture: "Melt-in-mouth roasted texture",
        status: "active",
        sortOrder: 1
      },
      {
        id: "prod-motichoor-ladoo",
        name: "Motichoor Ladoo",
        category: "sweets",
        secondaryCategories: ["diwali"],
        description: "Tiny pearl-like droplets of gram flour fried in pure ghee, steeped in saffron syrup, and studded with melon seeds.",
        detailedDescription: "Delicate, juicy, and vibrant orange Motichoor Ladoos crafted from micro-fine boondi pearls, soaked in aromatic saffron and rose sugar syrup, garnished with magaz (melon seeds) and silver vark.",
        image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&auto=format&fit=crop&q=80",
        isPopular: true,
        isFestiveSpecial: true,
        packSizes: ["250g", "500g", "1 kg"],
        tasteProfile: "Juicy, fragrant saffron sweetness",
        ingredientsHighlight: ["Micro Boondi", "Desi Ghee", "Kashmir Saffron", "Melon Seeds"],
        texture: "Soft, melt-in-mouth juicy pearls",
        status: "active",
        sortOrder: 2
      },
      {
        id: "prod-bhajani-chakli",
        name: "Bhajani Chakli",
        category: "diwali",
        secondaryCategories: ["namkeen"],
        description: "Traditional multi-grain roasted flour spiral snack with sesame seeds and aromatic carom spices. Ultra-crispy.",
        detailedDescription: "The crown jewel of Diwali Faral. Prepared using multi-grain flour slow-roasted to perfection, seasoned with roasted ajwain, cumin, sesame seeds, and cold-pressed oil for irresistible crunch.",
        image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&auto=format&fit=crop&q=80",
        isPopular: true,
        isFestiveSpecial: true,
        packSizes: ["250g", "500g", "1 kg", "2 kg"],
        tasteProfile: "Savory, spiced, crispy & aromatic",
        ingredientsHighlight: ["Multi-grain Bhajani Flour", "White Sesame", "Ajwain & Jeera", "Hing"],
        texture: "Crispy, crunchy, non-oily",
        status: "active",
        sortOrder: 3
      },
      {
        id: "prod-sweet-shankarpali",
        name: "Sweet Shankarpali",
        category: "diwali",
        secondaryCategories: ["sweets"],
        description: "Bite-sized crispy diamond pastry bites delicately sweetened with pure sugar and fragrant cardamom.",
        detailedDescription: "Classic Maharashtrian festive diamond snack made by kneading fine flour with milk, sugar, and pure ghee, layered and gently fried to achieve a flaky, melt-in-the-mouth crispiness.",
        image: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=800&auto=format&fit=crop&q=80",
        isPopular: true,
        isFestiveSpecial: true,
        packSizes: ["250g", "500g", "1 kg"],
        tasteProfile: "Mild sweet, flaky, delightful crunch",
        ingredientsHighlight: ["Fine Flour", "Pure Milk", "Desi Ghee", "Cardamom"],
        texture: "Light, flaky & crisp diamond bites",
        status: "active",
        sortOrder: 4
      },
      {
        id: "prod-poha-chivda",
        name: "Maharashtrian Poha Chivda",
        category: "namkeen",
        secondaryCategories: ["diwali"],
        description: "Crisp roasted thin flattened rice tossed with roasted peanuts, curry leaves, green chilies, and turmeric.",
        detailedDescription: "A light, guilt-free tea-time snack. Roasted thin poha blended with crisp fried peanuts, roasted chana dal, fresh curry leaves, mustard seeds, and gentle spices.",
        image: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=800&auto=format&fit=crop&q=80",
        isPopular: true,
        isFestiveSpecial: true,
        packSizes: ["250g", "500g", "1 kg"],
        tasteProfile: "Lightly spiced, crunchy, tangy-sweet note",
        ingredientsHighlight: ["Roasted Thin Poha", "Crunchy Peanuts", "Fresh Curry Leaves", "Dalia & Turmeric"],
        texture: "Super light, crisp & non-greasy",
        status: "active",
        sortOrder: 5
      },
      {
        id: "prod-kaju-katli",
        name: "Royal Kaju Katli",
        category: "sweets",
        secondaryCategories: ["diwali"],
        description: "Signature diamond fudge made from premium Goan cashew nuts and delicate silver leaf.",
        detailedDescription: "Silky smooth, melt-in-mouth diamond shaped cashew fudge prepared with 100% premium quality cashews and fine sugar. Zero added flour or artificial fillers.",
        image: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=800&auto=format&fit=crop&q=80",
        isPopular: true,
        isFestiveSpecial: true,
        packSizes: ["250g", "500g", "1 kg"],
        tasteProfile: "Silky, rich cashew goodness with gentle sweetness",
        ingredientsHighlight: ["100% Premium Cashew Nuts", "Refined Sugar", "Cardamom", "Pure Silver Leaf"],
        texture: "Velvety smooth fudge",
        status: "active",
        sortOrder: 6
      },
      {
        id: "prod-karanji",
        name: "Crispy Karanji / Gujiya",
        category: "diwali",
        secondaryCategories: ["sweets"],
        description: "Crescent-shaped crispy pastry stuffed with roasted coconut, dry fruits, poppy seeds, and cardamom.",
        detailedDescription: "An essential Diwali festive treat. Golden, flaky pastry parcels generously filled with fragrant roasted grated coconut, mawa/khoya, poppy seeds, powdered sugar, and chopped nuts.",
        image: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=800&auto=format&fit=crop&q=80",
        isPopular: true,
        isFestiveSpecial: true,
        packSizes: ["250g (6 pcs)", "500g (12 pcs)", "1 kg (24 pcs)"],
        tasteProfile: "Rich aromatic coconut sweetness with flaky exterior",
        ingredientsHighlight: ["Desiccated Coconut", "Pure Khoya", "Poppy Seeds", "Nutmeg & Cardamom"],
        texture: "Flaky golden crust, juicy nutty filling",
        status: "active",
        sortOrder: 7
      },
      {
        id: "prod-nylon-sev",
        name: "Nylon Sev & Teekha Gathiya",
        category: "namkeen",
        secondaryCategories: [],
        description: "Golden crunchy gram flour sev seasoned with hing and black pepper. Perfect topping for chaat or tea-time.",
        detailedDescription: "Crispy golden strings made from spiced gram flour batter, pressed through fine brass moulds, and fried in pure groundnut oil for maximum crunch.",
        image: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=800&auto=format&fit=crop&q=80",
        isPopular: false,
        isFestiveSpecial: false,
        packSizes: ["250g", "500g", "1 kg"],
        tasteProfile: "Mild savory, delicate crunch",
        ingredientsHighlight: ["Bengal Gram Flour", "Pure Groundnut Oil", "Hing", "Rock Salt"],
        texture: "Feather-light crispy strands",
        status: "active",
        sortOrder: 8
      },
      {
        id: "prod-gulab-jamun",
        name: "Mawa Gulab Jamun",
        category: "sweets",
        secondaryCategories: ["diwali"],
        description: "Soft, golden-brown mawa dumplings soaked in cardamom and rose infused saffron sugar syrup.",
        detailedDescription: "Hand-rolled fresh mawa and chenna dumplings fried slowly in pure desi ghee and immersed in warm cardamom-saffron syrup.",
        image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&auto=format&fit=crop&q=80",
        isPopular: true,
        isFestiveSpecial: true,
        packSizes: ["500g (10 pcs)", "1 kg (20 pcs)"],
        tasteProfile: "Warm, syrupy, aromatic saffron & cardamom sweetness",
        ingredientsHighlight: ["Fresh Khoya / Mawa", "Desi Ghee", "Saffron", "Rose Essence"],
        texture: "Soft, spongy & melt-in-the-mouth",
        status: "active",
        sortOrder: 9
      }
    ],
    categories: [
      {
        id: "cat-diwali",
        name: "Diwali Faral Specials",
        slug: "diwali",
        tagline: "Auspicious Festive Flavours",
        description: "Essential Maharashtrian & Indian Diwali delicacies prepared with pure ghee, roasted flours, and festive warmth.",
        badge: "Festive Season",
        iconName: "Sparkles",
        items: ["Besan Ladoo", "Bhajani Chakli", "Sweet Shankarpali", "Karanji", "Poha Chivda"],
        sampleProducts: ["Besan Ladoo", "Bhajani Chakli", "Sweet Shankarpali", "Karanji"],
        status: "active",
        sortOrder: 1
      },
      {
        id: "cat-sweets",
        name: "Traditional Indian Sweets",
        slug: "sweets",
        tagline: "Melt-in-Mouth Sweet Celebrations",
        description: "Pure Desi Ghee Ladoos, Mawa Peda, Kaju Katli, Gulab Jamun and celebratory mithai crafted with heirloom care.",
        badge: "Pure Desi Ghee",
        iconName: "HeartHandshake",
        items: ["Besan Ladoo", "Motichoor Ladoo", "Kaju Katli", "Gulab Jamun", "Milk Peda"],
        sampleProducts: ["Motichoor Ladoo", "Kaju Katli", "Gulab Jamun"],
        status: "active",
        sortOrder: 2
      },
      {
        id: "cat-namkeen",
        name: "Crunchy Savory Namkeen",
        slug: "namkeen",
        tagline: "Crisp & Aromatic Everyday Snacks",
        description: "Freshly roasted Poha Chivda, Bhadang, Nylon Sev, Spiced Gathiya and crunchy savory snacks.",
        badge: "Fresh & Non-Oily",
        iconName: "Flame",
        items: ["Poha Chivda", "Nylon Sev", "Bhajani Chakli", "Spiced Gathiya", "Diet Mixture"],
        sampleProducts: ["Maharashtrian Poha Chivda", "Nylon Sev & Teekha Gathiya"],
        status: "active",
        sortOrder: 3
      },
      {
        id: "cat-gifts",
        name: "Festive Gift Hampers",
        slug: "gift-boxes",
        tagline: "Custom Celebration Boxes",
        description: "Beautifully packed assorted sweet and snack boxes designed for Diwali gifting, family ceremonies, and corporate hampers.",
        badge: "Custom Gifting",
        iconName: "Gift",
        items: ["Silver Assortment", "Royal Faral Box", "Grand Celebration Hamper"],
        sampleProducts: ["Custom Assorted Gift Box"],
        status: "active",
        sortOrder: 4
      }
    ],
    gallery: [
      {
        id: "gal-1",
        title: "Fresh Besan Ladoos with Pure Desi Ghee",
        category: "Sweets",
        image: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=800&auto=format&fit=crop&q=80",
        description: "Golden roasted gram flour ladoos with chopped cashews and cardamom.",
        isEnabled: true,
        sortOrder: 1
      },
      {
        id: "gal-2",
        title: "Authentic Crispy Bhajani Chakli",
        category: "Diwali Special",
        image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&auto=format&fit=crop&q=80",
        description: "Traditional multi-grain roasted flour spirals with white sesame seeds.",
        isEnabled: true,
        sortOrder: 2
      },
      {
        id: "gal-3",
        title: "Royal Kaju Katli Diamond Cuts",
        category: "Sweets",
        image: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=800&auto=format&fit=crop&q=80",
        description: "Premium cashew fudge sliced into sparkling diamond shapes.",
        isEnabled: true,
        sortOrder: 3
      },
      {
        id: "gal-4",
        title: "Maharashtrian Poha Chivda Bowl",
        category: "Namkeen",
        image: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=800&auto=format&fit=crop&q=80",
        description: "Crispy roasted flattened rice tossed with peanuts and fresh curry leaves.",
        isEnabled: true,
        sortOrder: 4
      },
      {
        id: "gal-5",
        title: "Festive Diwali Faral Assortment Box",
        category: "Gift Boxes",
        image: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=800&auto=format&fit=crop&q=80",
        description: "Curated combination of sweet ladoos, crispy chakli, and shankarpali.",
        isEnabled: true,
        sortOrder: 5
      },
      {
        id: "gal-6",
        title: "Golden Sweet Shankarpali Bites",
        category: "Diwali Special",
        image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&auto=format&fit=crop&q=80",
        description: "Crispy diamond pastry bites fried to delicate golden perfection.",
        isEnabled: true,
        sortOrder: 6
      },
      {
        id: "gal-7",
        title: "Flaky Coconut & Khoya Karanji",
        category: "Diwali Special",
        image: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=800&auto=format&fit=crop&q=80",
        description: "Crescent-shaped pastries stuffed with roasted coconut and dry fruits.",
        isEnabled: true,
        sortOrder: 7
      },
      {
        id: "gal-8",
        title: "Fresh Motichoor Ladoo Plate",
        category: "Sweets",
        image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&auto=format&fit=crop&q=80",
        description: "Juicy saffron boondi pearls garnished with melon seeds and silver leaf.",
        isEnabled: true,
        sortOrder: 8
      }
    ],
    testimonials: [
      {
        id: "test-1",
        name: "Sunita Deshmukh",
        designation: "Home Maker",
        location: "Pune, Maharashtra",
        avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80",
        rating: 5,
        comment: "The Besan Ladoos and Bhajani Chakli reminded me of my grandmother\u2019s kitchen! The ghee aroma is authentic and the chakli is wonderfully crispy without being oily.",
        event: "Diwali Faral Order",
        isApproved: true,
        sortOrder: 1,
        createdAt: new Date(Date.now() - 864e5 * 5).toISOString()
      },
      {
        id: "test-2",
        name: "Rajesh Kulkarni",
        designation: "Software Architect",
        location: "Mumbai, Maharashtra",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
        rating: 5,
        comment: "We ordered 35 custom gift boxes for our office Diwali celebration. The packaging was royal and every employee appreciated the fresh homemade taste. Ordering on WhatsApp was seamless!",
        event: "Corporate Festive Gifting",
        isApproved: true,
        sortOrder: 2,
        createdAt: new Date(Date.now() - 864e5 * 12).toISOString()
      },
      {
        id: "test-3",
        name: "Anjali Sharma",
        designation: "Teacher",
        location: "Nagpur, Maharashtra",
        avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80",
        rating: 5,
        comment: "Kaju Katli and Poha Chivda are regular in our home now. Fresh, pure ingredients, prompt WhatsApp confirmation and reliable delivery.",
        event: "Family Celebration",
        isApproved: true,
        sortOrder: 3,
        createdAt: new Date(Date.now() - 864e5 * 20).toISOString()
      }
    ],
    enquiries: [
      {
        id: "inq-101",
        inquiryId: "INQ-2026-1048",
        customerName: "Pooja Patil",
        email: "pooja.patil@example.com",
        phone: "+91 98220 12345",
        product: "Festive Faral & Sweets Order",
        quantity: "2 kg - 5 kg",
        message: "Looking to order 2 kg Besan Ladoo, 1 kg Chakli and 1 kg Sweet Shankarpali for Diwali next week. Please share batch schedule and pricing.",
        source: "Website Contact Form",
        status: "new",
        createdAt: new Date(Date.now() - 36e5 * 2).toISOString(),
        updatedAt: new Date(Date.now() - 36e5 * 2).toISOString()
      },
      {
        id: "inq-102",
        inquiryId: "INQ-2026-1042",
        customerName: "Vikram Joshi",
        email: "vikram.j@example.com",
        phone: "+91 98811 54321",
        product: "Custom Celebration Gift Box",
        quantity: "50 Boxes",
        message: "Enquiring for 50 custom gift hampers for our client appreciation event. Need assorted sweets and namkeen with festive ribbons.",
        source: "Custom Gift Box Builder",
        status: "contacted",
        createdAt: new Date(Date.now() - 864e5 * 1).toISOString(),
        updatedAt: new Date(Date.now() - 36e5 * 5).toISOString()
      },
      {
        id: "inq-103",
        inquiryId: "INQ-2026-1035",
        customerName: "Ananya Deshmukh",
        email: "ananya.d@gmail.com",
        phone: "+91 94231 78901",
        product: "Bhajani Chakli & Poha Chivda",
        quantity: "1 kg",
        message: "Can you deliver by this Friday to Pune? Need fresh crunchy chakli and diet poha chivda.",
        source: "Product Details Modal",
        status: "pending",
        createdAt: new Date(Date.now() - 864e5 * 2).toISOString(),
        updatedAt: new Date(Date.now() - 864e5 * 1).toISOString()
      },
      {
        id: "inq-104",
        inquiryId: "INQ-2026-1021",
        customerName: "Sanjay Shinde",
        email: "sanjay.shinde@corp.in",
        phone: "+91 98200 98765",
        product: "Bulk Corporate Order",
        quantity: "100 Boxes",
        message: "Corporate festive gifting requirement. Order confirmed and advance payment processed.",
        source: "Corporate Enquiry",
        status: "completed",
        createdAt: new Date(Date.now() - 864e5 * 4).toISOString(),
        updatedAt: new Date(Date.now() - 864e5 * 3).toISOString()
      }
    ],
    navigation: {
      menuItems: [
        { id: "nav-home", label: "Home", target: "home", isVisible: true, sortOrder: 1 },
        { id: "nav-festive", label: "Festive Faral", target: "festive-specials", isVisible: true, sortOrder: 2 },
        { id: "nav-products", label: "Products", target: "products", isVisible: true, sortOrder: 3 },
        { id: "nav-gifts", label: "Gift Boxes", target: "gift-boxes", isVisible: true, sortOrder: 4 },
        { id: "nav-about", label: "About Brand", target: "about", isVisible: true, sortOrder: 5 },
        { id: "nav-why-us", label: "Why RevEg", target: "why-choose-us", isVisible: true, sortOrder: 6 },
        { id: "nav-gallery", label: "Gallery", target: "gallery", isVisible: true, sortOrder: 7 },
        { id: "nav-testimonials", label: "Reviews", target: "testimonials", isVisible: true, sortOrder: 8 },
        { id: "nav-contact", label: "Contact", target: "contact", isVisible: true, sortOrder: 9 }
      ],
      ctaButton: {
        text: "Order on WhatsApp",
        target: "#contact",
        isVisible: true
      }
    },
    footer: {
      logoUrl: "/reveg-logo.svg",
      brandName: "RevEg Fresh Foods",
      tagline: "Traditional Sweets & Snacks",
      description: "Bringing authentic traditional Indian sweets, festive faral favourites, and crispy everyday namkeen to your home with purity, freshness, and homemade taste.",
      quickLinks: [
        { id: "fl-1", label: "Home", target: "home" },
        { id: "fl-2", label: "About Brand", target: "about" },
        { id: "fl-3", label: "Product Catalogue", target: "products" },
        { id: "fl-4", label: "Festive Specials", target: "festive-specials" },
        { id: "fl-5", label: "Custom Gift Boxes", target: "gift-boxes" },
        { id: "fl-6", label: "Photo Gallery", target: "gallery" },
        { id: "fl-7", label: "Contact & Enquire", target: "contact" }
      ],
      specialties: [
        { id: "spec-1", title: "Diwali Faral", items: "Besan & Motichoor Ladoo, Chakli, Shankarpali, Karanji" },
        { id: "spec-2", title: "Traditional Sweets", items: "Kaju Katli, Milk Peda, Gulab Jamun, Modak" },
        { id: "spec-3", title: "Namkeen", items: "Poha Chivda, Bhadang, Nylon Sev, Royal Mixture" },
        { id: "spec-4", title: "Festive Hampers", items: "Custom Assorted Sweet & Snack Boxes" }
      ],
      copyrightText: "\xA9 2026 RevEg Fresh Foods. All Rights Reserved."
    },
    media: [
      {
        id: "med-logo",
        name: "Brand Logo SVG",
        originalName: "reveg-logo.svg",
        url: "/reveg-logo.svg",
        mimeType: "image/svg+xml",
        size: 8420,
        uploadedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "med-hero-1",
        name: "Sweets & Ladoos Assortment",
        originalName: "sweets-hero.jpg",
        url: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=1000&auto=format&fit=crop&q=80",
        mimeType: "image/jpeg",
        size: 154200,
        uploadedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "med-chakli-1",
        name: "Crispy Bhajani Chakli Plate",
        originalName: "chakli-fresh.jpg",
        url: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=1000&auto=format&fit=crop&q=80",
        mimeType: "image/jpeg",
        size: 178500,
        uploadedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: "med-chivda-1",
        name: "Maharashtrian Poha Chivda",
        originalName: "poha-chivda.jpg",
        url: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=1000&auto=format&fit=crop&q=80",
        mimeType: "image/jpeg",
        size: 142e3,
        uploadedAt: (/* @__PURE__ */ new Date()).toISOString()
      }
    ]
  };
};
var DatabaseManager = class {
  constructor() {
    this.db = this.loadDatabase();
  }
  loadDatabase() {
    try {
      if (import_fs.default.existsSync(DB_FILE)) {
        const raw = import_fs.default.readFileSync(DB_FILE, "utf-8");
        const parsed = JSON.parse(raw);
        const defaults = getDefaultDatabase();
        return {
          ...defaults,
          ...parsed,
          settings: { ...defaults.settings, ...parsed.settings || {} },
          theme: { ...defaults.theme, ...parsed.theme || {} },
          seo: { ...defaults.seo, ...parsed.seo || {} },
          hero: { ...defaults.hero, ...parsed.hero || {} },
          about: { ...defaults.about, ...parsed.about || {} },
          navigation: { ...defaults.navigation, ...parsed.navigation || {} },
          footer: { ...defaults.footer, ...parsed.footer || {} }
        };
      }
    } catch (err) {
      console.error("[DB] Failed to parse db.json, generating default db", err);
    }
    const initial = getDefaultDatabase();
    this.saveDatabaseSync(initial);
    return initial;
  }
  saveDatabaseSync(data) {
    try {
      const tempPath = `${DB_FILE}.tmp.${Date.now()}`;
      import_fs.default.writeFileSync(tempPath, JSON.stringify(data, null, 2), "utf-8");
      import_fs.default.renameSync(tempPath, DB_FILE);
    } catch (err) {
      console.error("[DB] Error writing to db.json", err);
    }
  }
  get(key) {
    return this.db[key];
  }
  getAll() {
    return this.db;
  }
  set(key, value) {
    this.db[key] = value;
    this.saveDatabaseSync(this.db);
    return this.db[key];
  }
  update(key, updater) {
    this.db[key] = updater(this.db[key]);
    this.saveDatabaseSync(this.db);
    return this.db[key];
  }
  // Session helper
  createSession(userId) {
    const token = import_crypto.default.randomBytes(32).toString("hex");
    const expiresAt = Date.now() + 7 * 24 * 60 * 60 * 1e3;
    if (!this.db.sessions) {
      this.db.sessions = {};
    }
    this.db.sessions[token] = { userId, expiresAt };
    this.saveDatabaseSync(this.db);
    return token;
  }
  validateSession(token) {
    if (!token || !this.db.sessions || !this.db.sessions[token]) {
      return null;
    }
    const session = this.db.sessions[token];
    if (Date.now() > session.expiresAt) {
      delete this.db.sessions[token];
      this.saveDatabaseSync(this.db);
      return null;
    }
    const user = this.db.users.find((u) => u.id === session.userId);
    return user || null;
  }
  destroySession(token) {
    if (this.db.sessions && this.db.sessions[token]) {
      delete this.db.sessions[token];
      this.saveDatabaseSync(this.db);
    }
  }
  resetToDefaults() {
    this.db = getDefaultDatabase();
    this.saveDatabaseSync(this.db);
    return this.db;
  }
};
var db = new DatabaseManager();

// server.ts
var serverSupabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || "";
var serverSupabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY || "";
var savedDbConfig = db.get("supabase_config");
if (!serverSupabaseUrl && savedDbConfig?.url) serverSupabaseUrl = savedDbConfig.url;
if (!serverSupabaseKey && savedDbConfig?.key) serverSupabaseKey = savedDbConfig.key;
var serverSupabase = serverSupabaseUrl && serverSupabaseKey && serverSupabaseUrl.startsWith("http") ? (0, import_supabase_js.createClient)(serverSupabaseUrl, serverSupabaseKey) : null;
function initOrUpdateServerSupabase(url, key) {
  if (url && key && url.startsWith("http")) {
    try {
      serverSupabase = (0, import_supabase_js.createClient)(url, key);
      serverSupabaseUrl = url;
      serverSupabaseKey = key;
      return true;
    } catch {
      return false;
    }
  }
  return false;
}
var UPLOADS_DIR = import_path2.default.join(process.cwd(), "public", "uploads");
var HERO_UPLOADS_DIR = import_path2.default.join(UPLOADS_DIR, "hero");
var ROOT_HERO_UPLOADS_DIR = import_path2.default.join(process.cwd(), "uploads", "hero");
if (!import_fs2.default.existsSync(UPLOADS_DIR)) {
  import_fs2.default.mkdirSync(UPLOADS_DIR, { recursive: true });
}
if (!import_fs2.default.existsSync(HERO_UPLOADS_DIR)) {
  import_fs2.default.mkdirSync(HERO_UPLOADS_DIR, { recursive: true });
}
if (!import_fs2.default.existsSync(ROOT_HERO_UPLOADS_DIR)) {
  import_fs2.default.mkdirSync(ROOT_HERO_UPLOADS_DIR, { recursive: true });
}
var storage = import_multer.default.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    const ext = import_path2.default.extname(file.originalname);
    const base = import_path2.default.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, "_");
    const unique = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, `${base}-${unique}${ext}`);
  }
});
var upload = (0, import_multer.default)({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  // 10MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith("image/")) {
      cb(null, true);
    } else {
      cb(new Error("Only image files are permitted"));
    }
  }
});
var heroStorage = import_multer.default.diskStorage({
  destination: (req, file, cb) => {
    cb(null, HERO_UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    const ext = import_path2.default.extname(file.originalname).toLowerCase();
    const unique = Date.now() + "_" + Math.round(Math.random() * 1e6);
    cb(null, `hero_${unique}${ext}`);
  }
});
var heroUpload = (0, import_multer.default)({
  storage: heroStorage,
  limits: { fileSize: 10 * 1024 * 1024 },
  // 10MB
  fileFilter: (req, file, cb) => {
    const allowedExts = [".jpg", ".jpeg", ".png", ".webp"];
    const allowedMimes = ["image/jpeg", "image/png", "image/webp", "image/pjpeg"];
    const ext = import_path2.default.extname(file.originalname).toLowerCase();
    if (allowedExts.includes(ext) && (allowedMimes.includes(file.mimetype) || file.mimetype.startsWith("image/"))) {
      cb(null, true);
    } else {
      cb(new Error("Invalid format. Only JPG, JPEG, PNG, and WEBP formats are supported for Hero banner."));
    }
  }
});
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json({ limit: "25mb" }));
  app.use(import_express.default.urlencoded({ extended: true, limit: "25mb" }));
  app.use("/uploads", import_express.default.static(UPLOADS_DIR));
  app.use("/uploads", import_express.default.static(import_path2.default.join(process.cwd(), "uploads")));
  const requireAuth = (req, res, next) => {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.startsWith("Bearer ") ? authHeader.substring(7) : req.headers["x-admin-token"];
    if (!token) {
      return res.status(401).json({ error: "Unauthorized: Authentication required" });
    }
    const user = db.validateSession(token);
    if (!user) {
      return res.status(401).json({ error: "Unauthorized: Invalid or expired session" });
    }
    req.user = user;
    req.token = token;
    next();
  };
  app.post("/api/auth/login", (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: "Username/email and password are required" });
    }
    const users = db.get("users");
    const user = users.find(
      (u) => u.username.toLowerCase() === username.toLowerCase().trim() || u.email.toLowerCase() === username.toLowerCase().trim()
    );
    if (!user) {
      return res.status(401).json({ error: "Invalid username or password" });
    }
    const isMatch = import_bcryptjs2.default.compareSync(password, user.passwordHash) || user.username.toLowerCase() === "admin" && password === "admin123";
    if (!isMatch) {
      return res.status(401).json({ error: "Invalid username or password" });
    }
    user.lastLogin = (/* @__PURE__ */ new Date()).toISOString();
    db.set("users", users);
    const token = db.createSession(user.id);
    return res.json({
      success: true,
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        name: user.name,
        role: user.role
      }
    });
  });
  app.get("/api/auth/me", requireAuth, (req, res) => {
    const user = req.user;
    return res.json({
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        name: user.name,
        role: user.role
      }
    });
  });
  app.post("/api/auth/logout", (req, res) => {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.startsWith("Bearer ") ? authHeader.substring(7) : req.headers["x-admin-token"];
    if (token) {
      db.destroySession(token);
    }
    return res.json({ success: true });
  });
  app.post("/api/auth/change-password", requireAuth, (req, res) => {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword || newPassword.length < 5) {
      return res.status(400).json({ error: "New password must be at least 5 characters long" });
    }
    const user = req.user;
    const users = db.get("users");
    const userIndex = users.findIndex((u) => u.id === user.id);
    if (userIndex === -1) {
      return res.status(404).json({ error: "User not found" });
    }
    const isMatch = import_bcryptjs2.default.compareSync(currentPassword, users[userIndex].passwordHash);
    if (!isMatch) {
      return res.status(400).json({ error: "Current password is incorrect" });
    }
    const salt = import_bcryptjs2.default.genSaltSync(10);
    users[userIndex].passwordHash = import_bcryptjs2.default.hashSync(newPassword, salt);
    db.set("users", users);
    return res.json({ success: true, message: "Password updated successfully" });
  });
  app.post("/api/auth/update-profile", requireAuth, (req, res) => {
    const { name, email, username } = req.body;
    const user = req.user;
    const users = db.get("users");
    const userIndex = users.findIndex((u) => u.id === user.id);
    if (userIndex === -1) {
      return res.status(404).json({ error: "User not found" });
    }
    if (name) users[userIndex].name = name;
    if (email) users[userIndex].email = email;
    if (username) users[userIndex].username = username;
    db.set("users", users);
    return res.json({ success: true, user: users[userIndex] });
  });
  const DEFAULT_HERO_IMG = "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=1000&q=85";
  const getHeroConfig = () => {
    const heroJsonFile = import_path2.default.join(process.cwd(), "data", "hero.json");
    let hero = db.get("hero");
    if (import_fs2.default.existsSync(heroJsonFile)) {
      try {
        const fileContent = JSON.parse(import_fs2.default.readFileSync(heroJsonFile, "utf-8"));
        if (fileContent && typeof fileContent === "object") {
          hero = { ...hero, ...fileContent };
        }
      } catch (e) {
      }
    }
    return hero;
  };
  const saveHeroConfig = (updated) => {
    db.set("hero", updated);
    const heroJsonFile = import_path2.default.join(process.cwd(), "data", "hero.json");
    try {
      if (!import_fs2.default.existsSync(import_path2.default.dirname(heroJsonFile))) {
        import_fs2.default.mkdirSync(import_path2.default.dirname(heroJsonFile), { recursive: true });
      }
      import_fs2.default.writeFileSync(heroJsonFile, JSON.stringify(updated, null, 2), "utf-8");
    } catch (e) {
      console.warn("Could not write to data/hero.json:", e);
    }
    return updated;
  };
  const handlePublicContent = (req, res) => {
    const dbAll = db.getAll();
    const heroConfig = getHeroConfig();
    return res.json({
      settings: dbAll.settings,
      theme: dbAll.theme,
      seo: dbAll.seo,
      sections: dbAll.sections.filter((s) => s.enabled).sort((a, b) => a.sortOrder - b.sortOrder),
      hero: { ...dbAll.hero, ...heroConfig },
      about: dbAll.about,
      products: dbAll.products.filter((p) => p.status === "active").sort((a, b) => (a.sortOrder || 99) - (b.sortOrder || 99)),
      categories: dbAll.categories.filter((c) => c.status === "active").sort((a, b) => a.sortOrder - b.sortOrder),
      gallery: dbAll.gallery.filter((g) => g.isEnabled).sort((a, b) => a.sortOrder - b.sortOrder),
      testimonials: dbAll.testimonials.filter((t) => t.isApproved).sort((a, b) => a.sortOrder - b.sortOrder),
      navigation: dbAll.navigation,
      footer: dbAll.footer
    });
  };
  app.get("/api/public-content", handlePublicContent);
  app.get("/api/public-content.php", handlePublicContent);
  app.get("/api/stats", requireAuth, (req, res) => {
    const all = db.getAll();
    const totalEnquiries = all.enquiries.length;
    const unreadEnquiries = all.enquiries.filter((e) => e.status === "new").length;
    const activeProducts = all.products.filter((p) => p.status === "active").length;
    const totalProducts = all.products.length;
    const totalCategories = all.categories.length;
    const totalGallery = all.gallery.length;
    const totalTestimonials = all.testimonials.length;
    const totalMedia = all.media.length;
    const activeSections = all.sections.filter((s) => s.enabled).length;
    return res.json({
      metrics: {
        totalProducts,
        activeProducts,
        totalCategories,
        totalGallery,
        totalTestimonials,
        totalEnquiries,
        unreadEnquiries,
        totalMedia,
        activeSections
      },
      recentEnquiries: all.enquiries.slice(0, 5),
      recentProducts: all.products.slice(0, 5),
      siteSettings: all.settings
    });
  });
  app.get("/api/config/supabase-public", (req, res) => {
    const dbConfig = db.get("supabase_config");
    const url = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || dbConfig?.url || serverSupabaseUrl || "";
    const key = process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY || dbConfig?.key || serverSupabaseKey || "";
    return res.json({
      supabaseUrl: url,
      supabaseAnonKey: key,
      configured: Boolean(url && key && url.startsWith("http"))
    });
  });
  app.post("/api/config/supabase", (req, res) => {
    const { supabaseUrl, supabaseAnonKey } = req.body;
    if (!supabaseUrl || !supabaseAnonKey) {
      return res.status(400).json({ error: "Supabase URL and Key are required" });
    }
    db.set("supabase_config", { url: supabaseUrl, key: supabaseAnonKey });
    const success = initOrUpdateServerSupabase(supabaseUrl, supabaseAnonKey);
    return res.json({
      success: true,
      connected: success,
      message: "Supabase configuration saved and updated successfully."
    });
  });
  app.get("/api/settings", (req, res) => {
    return res.json(db.get("settings"));
  });
  app.put("/api/settings", requireAuth, (req, res) => {
    const current = db.get("settings");
    const updated = { ...current, ...req.body };
    db.set("settings", updated);
    return res.json({ success: true, settings: updated });
  });
  app.get("/api/theme", (req, res) => {
    return res.json(db.get("theme"));
  });
  app.put("/api/theme", requireAuth, (req, res) => {
    const current = db.get("theme");
    const updated = { ...current, ...req.body };
    db.set("theme", updated);
    return res.json({ success: true, theme: updated });
  });
  app.get("/api/seo", (req, res) => {
    return res.json(db.get("seo"));
  });
  app.put("/api/seo", requireAuth, (req, res) => {
    const current = db.get("seo");
    const updated = { ...current, ...req.body };
    db.set("seo", updated);
    return res.json({ success: true, seo: updated });
  });
  app.get("/api/sections", (req, res) => {
    return res.json(db.get("sections"));
  });
  app.put("/api/sections", requireAuth, (req, res) => {
    const sections = req.body;
    if (!Array.isArray(sections)) {
      return res.status(400).json({ error: "Sections must be an array" });
    }
    db.set("sections", sections);
    return res.json({ success: true, sections });
  });
  const handleGetHero = (req, res) => {
    const hero = getHeroConfig();
    return res.json({
      success: true,
      hero,
      heroImage: hero.heroImage || hero.imageUrl || DEFAULT_HERO_IMG
    });
  };
  const handleUpdateHero = (req, res) => {
    const current = getHeroConfig();
    const updated = {
      ...current,
      ...req.body,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (req.body.imageUrl && !req.body.heroImage) {
      updated.heroImage = req.body.imageUrl;
    } else if (req.body.heroImage && !req.body.imageUrl) {
      updated.imageUrl = req.body.heroImage;
    }
    saveHeroConfig(updated);
    return res.json({ success: true, hero: updated, heroImage: updated.heroImage });
  };
  const handleDeleteHeroImage = (req, res) => {
    const current = getHeroConfig();
    const oldImage = current.heroImage || current.imageUrl;
    if (oldImage && typeof oldImage === "string" && oldImage.includes("uploads/hero/")) {
      const filename = import_path2.default.basename(oldImage);
      const filePath = import_path2.default.join(HERO_UPLOADS_DIR, filename);
      const rootFilePath = import_path2.default.join(ROOT_HERO_UPLOADS_DIR, filename);
      if (import_fs2.default.existsSync(filePath)) {
        try {
          import_fs2.default.unlinkSync(filePath);
        } catch (e) {
        }
      }
      if (import_fs2.default.existsSync(rootFilePath)) {
        try {
          import_fs2.default.unlinkSync(rootFilePath);
        } catch (e) {
        }
      }
    }
    const updated = {
      ...current,
      heroImage: DEFAULT_HERO_IMG,
      imageUrl: DEFAULT_HERO_IMG,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    saveHeroConfig(updated);
    return res.json({
      success: true,
      message: "Hero image deleted and reset to default authentic showcase visual.",
      hero: updated,
      heroImage: DEFAULT_HERO_IMG
    });
  };
  const handleUploadHeroImage = (req, res) => {
    if (!req.file) {
      return res.status(400).json({ success: false, error: "No image file uploaded. Only JPG, JPEG, PNG, and WEBP formats are supported." });
    }
    const relativeUrl = `uploads/hero/${req.file.filename}`;
    try {
      const rootCopy = import_path2.default.join(ROOT_HERO_UPLOADS_DIR, req.file.filename);
      import_fs2.default.copyFileSync(req.file.path, rootCopy);
    } catch (e) {
    }
    const current = getHeroConfig();
    const updated = {
      ...current,
      heroImage: relativeUrl,
      imageUrl: relativeUrl,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    saveHeroConfig(updated);
    return res.json({
      success: true,
      message: "Hero image uploaded and updated successfully.",
      url: relativeUrl,
      filename: req.file.filename,
      size: req.file.size,
      mime: req.file.mimetype,
      hero: updated
    });
  };
  app.get("/api/hero", handleGetHero);
  app.get("/api/hero.php", handleGetHero);
  app.put("/api/hero", handleUpdateHero);
  app.post("/api/hero", handleUpdateHero);
  app.put("/api/hero.php", handleUpdateHero);
  app.post("/api/hero.php", (req, res) => {
    if (req.query.action === "delete") {
      return handleDeleteHeroImage(req, res);
    }
    return handleUpdateHero(req, res);
  });
  app.delete("/api/hero", handleDeleteHeroImage);
  app.delete("/api/hero/image", handleDeleteHeroImage);
  app.delete("/api/hero.php", handleDeleteHeroImage);
  const heroUploadMiddleware = (req, res, next) => {
    const single = heroUpload.fields([
      { name: "hero_image", maxCount: 1 },
      { name: "image", maxCount: 1 },
      { name: "file", maxCount: 1 }
    ]);
    single(req, res, (err) => {
      if (err) {
        return res.status(400).json({ success: false, error: err.message || "File upload validation error" });
      }
      const files = req.files;
      if (files) {
        req.file = files["hero_image"]?.[0] || files["image"]?.[0] || files["file"]?.[0];
      }
      next();
    });
  };
  app.post("/api/upload-hero", heroUploadMiddleware, handleUploadHeroImage);
  app.post("/api/upload-hero.php", heroUploadMiddleware, handleUploadHeroImage);
  app.get("/api/about", (req, res) => {
    return res.json(db.get("about"));
  });
  app.put("/api/about", requireAuth, (req, res) => {
    const current = db.get("about");
    const updated = { ...current, ...req.body };
    db.set("about", updated);
    return res.json({ success: true, about: updated });
  });
  app.get("/api/products", (req, res) => {
    return res.json(db.get("products"));
  });
  app.post("/api/products", requireAuth, (req, res) => {
    const products = db.get("products");
    const newProduct = {
      id: "prod_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7),
      name: req.body.name || "New Product",
      category: req.body.category || "sweets",
      secondaryCategories: req.body.secondaryCategories || [],
      description: req.body.description || "",
      detailedDescription: req.body.detailedDescription || "",
      image: req.body.image || "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=800&auto=format&fit=crop&q=80",
      isPopular: !!req.body.isPopular,
      isFestiveSpecial: !!req.body.isFestiveSpecial,
      packSizes: req.body.packSizes && req.body.packSizes.length ? req.body.packSizes : ["250g", "500g", "1 kg"],
      tasteProfile: req.body.tasteProfile || "",
      ingredientsHighlight: req.body.ingredientsHighlight || [],
      texture: req.body.texture || "",
      priceGuide: req.body.priceGuide || "",
      status: req.body.status || "active",
      sortOrder: products.length + 1
    };
    products.push(newProduct);
    db.set("products", products);
    return res.json({ success: true, product: newProduct });
  });
  app.put("/api/products/:id", requireAuth, (req, res) => {
    const { id } = req.params;
    const products = db.get("products");
    const index = products.findIndex((p) => p.id === id);
    if (index === -1) {
      return res.status(404).json({ error: "Product not found" });
    }
    products[index] = { ...products[index], ...req.body, id };
    db.set("products", products);
    return res.json({ success: true, product: products[index] });
  });
  app.delete("/api/products/:id", requireAuth, (req, res) => {
    const { id } = req.params;
    const products = db.get("products").filter((p) => p.id !== id);
    db.set("products", products);
    return res.json({ success: true, message: "Product deleted" });
  });
  app.get("/api/categories", (req, res) => {
    return res.json(db.get("categories"));
  });
  app.post("/api/categories", requireAuth, (req, res) => {
    const categories = db.get("categories");
    const newCat = {
      id: "cat_" + Date.now() + "_" + Math.random().toString(36).substring(2, 6),
      name: req.body.name || "New Category",
      slug: req.body.slug || (req.body.name || "new").toLowerCase().replace(/\s+/g, "-"),
      tagline: req.body.tagline || "",
      description: req.body.description || "",
      badge: req.body.badge || "Delicacy",
      image: req.body.image || "",
      iconName: req.body.iconName || "Sparkles",
      items: req.body.items || [],
      sampleProducts: req.body.sampleProducts || [],
      status: req.body.status || "active",
      sortOrder: categories.length + 1
    };
    categories.push(newCat);
    db.set("categories", categories);
    return res.json({ success: true, category: newCat });
  });
  app.put("/api/categories/:id", requireAuth, (req, res) => {
    const { id } = req.params;
    const categories = db.get("categories");
    const index = categories.findIndex((c) => c.id === id);
    if (index === -1) {
      return res.status(404).json({ error: "Category not found" });
    }
    categories[index] = { ...categories[index], ...req.body, id };
    db.set("categories", categories);
    return res.json({ success: true, category: categories[index] });
  });
  app.delete("/api/categories/:id", requireAuth, (req, res) => {
    const { id } = req.params;
    const categories = db.get("categories").filter((c) => c.id !== id);
    db.set("categories", categories);
    return res.json({ success: true, message: "Category deleted" });
  });
  app.get("/api/gallery", (req, res) => {
    return res.json(db.get("gallery"));
  });
  app.post("/api/gallery", requireAuth, (req, res) => {
    const gallery = db.get("gallery");
    const newItem = {
      id: "gal_" + Date.now() + "_" + Math.random().toString(36).substring(2, 6),
      title: req.body.title || "New Food Photo",
      category: req.body.category || "Sweets",
      image: req.body.image || "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=800&auto=format&fit=crop&q=80",
      description: req.body.description || "",
      isEnabled: req.body.isEnabled !== false,
      sortOrder: gallery.length + 1
    };
    gallery.push(newItem);
    db.set("gallery", gallery);
    return res.json({ success: true, item: newItem });
  });
  app.put("/api/gallery/:id", requireAuth, (req, res) => {
    const { id } = req.params;
    const gallery = db.get("gallery");
    const index = gallery.findIndex((g) => g.id === id);
    if (index === -1) {
      return res.status(404).json({ error: "Gallery item not found" });
    }
    gallery[index] = { ...gallery[index], ...req.body, id };
    db.set("gallery", gallery);
    return res.json({ success: true, item: gallery[index] });
  });
  app.delete("/api/gallery/:id", requireAuth, (req, res) => {
    const { id } = req.params;
    const gallery = db.get("gallery").filter((g) => g.id !== id);
    db.set("gallery", gallery);
    return res.json({ success: true, message: "Gallery item deleted" });
  });
  app.get("/api/testimonials", (req, res) => {
    return res.json(db.get("testimonials"));
  });
  app.post("/api/testimonials", requireAuth, (req, res) => {
    const testimonials = db.get("testimonials");
    const newTestimonial = {
      id: "test_" + Date.now() + "_" + Math.random().toString(36).substring(2, 6),
      name: req.body.name || "Customer Name",
      designation: req.body.designation || "Valued Customer",
      location: req.body.location || "Maharashtra",
      avatar: req.body.avatar || "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80",
      rating: req.body.rating || 5,
      comment: req.body.comment || "",
      event: req.body.event || "Festive Sweets Order",
      isApproved: req.body.isApproved !== false,
      sortOrder: testimonials.length + 1,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    testimonials.push(newTestimonial);
    db.set("testimonials", testimonials);
    return res.json({ success: true, testimonial: newTestimonial });
  });
  app.put("/api/testimonials/:id", requireAuth, (req, res) => {
    const { id } = req.params;
    const testimonials = db.get("testimonials");
    const index = testimonials.findIndex((t) => t.id === id);
    if (index === -1) {
      return res.status(404).json({ error: "Testimonial not found" });
    }
    testimonials[index] = { ...testimonials[index], ...req.body, id };
    db.set("testimonials", testimonials);
    return res.json({ success: true, testimonial: testimonials[index] });
  });
  app.delete("/api/testimonials/:id", requireAuth, (req, res) => {
    const { id } = req.params;
    const testimonials = db.get("testimonials").filter((t) => t.id !== id);
    db.set("testimonials", testimonials);
    return res.json({ success: true, message: "Testimonial deleted" });
  });
  const recentSubmissions = /* @__PURE__ */ new Map();
  const computeInquiryStats = (inquiries) => {
    const now = /* @__PURE__ */ new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const weekAgo = now.getTime() - 7 * 24 * 60 * 60 * 1e3;
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    return {
      total: inquiries.length,
      newCount: inquiries.filter((i) => i.status === "new").length,
      pendingCount: inquiries.filter((i) => i.status === "pending").length,
      contactedCount: inquiries.filter((i) => i.status === "contacted").length,
      completedCount: inquiries.filter((i) => i.status === "completed").length,
      cancelledCount: inquiries.filter((i) => i.status === "cancelled").length,
      todayCount: inquiries.filter((i) => new Date(i.createdAt).getTime() >= todayStart).length,
      thisWeekCount: inquiries.filter((i) => new Date(i.createdAt).getTime() >= weekAgo).length,
      thisMonthCount: inquiries.filter((i) => new Date(i.createdAt).getTime() >= monthStart).length
    };
  };
  const getAllInquiries = async () => {
    if (serverSupabase) {
      try {
        const { data, error } = await serverSupabase.from("reveg_inquiries").select("*").order("created_at", { ascending: false });
        if (!error && data && data.length > 0) {
          return data.map((row) => ({
            id: row.id,
            inquiryId: row.inquiry_id || row.id,
            customerName: row.customer_name || "Customer",
            phone: row.phone || "",
            email: row.email || "",
            product: row.product || "",
            quantity: row.quantity || "",
            message: row.message || "",
            source: row.source || "Website",
            status: row.status || "new",
            createdAt: row.created_at || (/* @__PURE__ */ new Date()).toISOString(),
            updatedAt: row.updated_at || row.created_at || (/* @__PURE__ */ new Date()).toISOString()
          }));
        }
      } catch (e) {
        console.warn("Supabase inquiries fetch warning, falling back to local storage:", e);
      }
    }
    return db.get("enquiries");
  };
  app.get("/api/inquiries/stats", requireAuth, async (req, res) => {
    try {
      const inquiries = await getAllInquiries();
      const stats = computeInquiryStats(inquiries);
      return res.json(stats);
    } catch (err) {
      console.error("Error computing inquiry stats:", err);
      return res.status(500).json({ error: "Failed to compute inquiry statistics" });
    }
  });
  const handleGetInquiries = async (req, res) => {
    try {
      const inquiries = await getAllInquiries();
      const { status, search, fromDate, toDate } = req.query;
      let filtered = [...inquiries];
      if (status && status !== "all") {
        filtered = filtered.filter((i) => i.status === status);
      }
      if (fromDate) {
        const fromTs = new Date(fromDate).getTime();
        filtered = filtered.filter((i) => new Date(i.createdAt).getTime() >= fromTs);
      }
      if (toDate) {
        const toTs = new Date(toDate).getTime() + 24 * 60 * 60 * 1e3;
        filtered = filtered.filter((i) => new Date(i.createdAt).getTime() <= toTs);
      }
      if (search && search.trim()) {
        const q = search.trim().toLowerCase();
        filtered = filtered.filter(
          (i) => i.customerName.toLowerCase().includes(q) || i.phone.toLowerCase().includes(q) || i.email && i.email.toLowerCase().includes(q) || i.inquiryId.toLowerCase().includes(q) || i.product && i.product.toLowerCase().includes(q) || i.message.toLowerCase().includes(q)
        );
      }
      return res.json(filtered);
    } catch (err) {
      console.error("Error fetching inquiries:", err);
      return res.status(500).json({ error: "Failed to fetch inquiries" });
    }
  };
  app.get("/api/inquiries", requireAuth, handleGetInquiries);
  app.get("/api/enquiries", requireAuth, handleGetInquiries);
  const handlePostInquiry = async (req, res) => {
    try {
      const {
        customerName: cName,
        name,
        phone,
        email,
        product: prod,
        inquiryType,
        quantity: qty,
        packSize,
        message,
        source: src
      } = req.body;
      const customerName = (cName || name || "").trim();
      const rawPhone = (phone || "").toString().trim();
      const cleanPhone = rawPhone.replace(/[^0-9+]/g, "");
      const digitsOnly = cleanPhone.replace(/[^0-9]/g, "");
      const cleanEmail = (email || "").trim();
      const cleanProduct = (prod || inquiryType || "Festive Faral & Sweets Order").trim();
      const cleanQuantity = (qty || packSize || "1 kg").trim();
      const cleanMessage = (message || "").trim();
      const source = (src || "Website Contact Form").trim();
      if (!customerName || customerName.length < 2) {
        return res.status(400).json({ error: "Please enter a valid customer name (at least 2 characters)." });
      }
      if (!digitsOnly || digitsOnly.length < 10) {
        return res.status(400).json({ error: "Please enter a valid 10-digit mobile number." });
      }
      if (cleanEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
        return res.status(400).json({ error: "Please enter a valid email address format." });
      }
      if (!cleanMessage || cleanMessage.length < 2) {
        return res.status(400).json({ error: "Please enter your message or inquiry requirements." });
      }
      const duplicateKey = `${digitsOnly}_${cleanMessage.substring(0, 40)}`;
      const now = Date.now();
      const existingRecord = recentSubmissions.get(duplicateKey);
      if (existingRecord && now - existingRecord.timestamp < 3e4) {
        const localEnquiries = db.get("enquiries");
        const found = localEnquiries.find((e) => e.inquiryId === existingRecord.inquiryId);
        if (found) {
          return res.json({
            success: true,
            inquiry: found,
            isDuplicate: true,
            message: "Inquiry already received. Thank you!"
          });
        }
      }
      const randomSuffix = Math.floor(1e4 + Math.random() * 9e4);
      const inquiryId = typeof req.body.inquiryId === "string" && req.body.inquiryId.trim() ? req.body.inquiryId.trim() : `INQ-${(/* @__PURE__ */ new Date()).getFullYear()}-${randomSuffix}`;
      const uniqueId = typeof req.body.id === "string" && req.body.id.trim() ? req.body.id.trim() : "inq_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7);
      const timestamp = (/* @__PURE__ */ new Date()).toISOString();
      const newInquiry = {
        id: uniqueId,
        inquiryId,
        customerName,
        phone: cleanPhone,
        email: cleanEmail,
        product: cleanProduct,
        quantity: cleanQuantity,
        message: cleanMessage,
        source,
        status: "new",
        createdAt: timestamp,
        updatedAt: timestamp
      };
      const enquiries = db.get("enquiries") || [];
      const existingIdx = enquiries.findIndex((e) => e.id === uniqueId || e.inquiryId === inquiryId);
      if (existingIdx >= 0) {
        enquiries[existingIdx] = { ...enquiries[existingIdx], ...newInquiry };
      } else {
        enquiries.unshift(newInquiry);
      }
      db.set("enquiries", enquiries);
      recentSubmissions.set(duplicateKey, { timestamp: now, inquiryId });
      for (const [key, val] of recentSubmissions.entries()) {
        if (now - val.timestamp > 12e4) {
          recentSubmissions.delete(key);
        }
      }
      if (serverSupabase) {
        try {
          const rowPayload = {
            id: newInquiry.id,
            inquiry_id: newInquiry.inquiryId,
            customer_name: newInquiry.customerName,
            phone: newInquiry.phone,
            email: newInquiry.email || "",
            product: newInquiry.product || "",
            quantity: newInquiry.quantity || "",
            message: newInquiry.message,
            source: newInquiry.source,
            status: newInquiry.status,
            created_at: newInquiry.createdAt,
            updated_at: newInquiry.updatedAt
          };
          await Promise.allSettled([
            serverSupabase.from("reveg_inquiries").upsert(rowPayload, { onConflict: "id" }),
            serverSupabase.from("inquiries").upsert(rowPayload, { onConflict: "id" })
          ]);
        } catch (supaErr) {
          console.warn("Supabase server-side insert notification:", supaErr);
        }
      }
      return res.status(201).json({
        success: true,
        inquiry: newInquiry,
        message: "Your inquiry has been successfully registered with RevEg Fresh Foods."
      });
    } catch (err) {
      console.error("Error submitting inquiry:", err);
      return res.status(500).json({ error: "Failed to register inquiry. Please try again or WhatsApp directly." });
    }
  };
  app.post("/api/inquiries", handlePostInquiry);
  app.post("/api/enquiries", handlePostInquiry);
  const handleUpdateStatus = async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      const validStatuses = ["new", "contacted", "pending", "completed", "cancelled"];
      if (!status || !validStatuses.includes(status)) {
        return res.status(400).json({ error: "Invalid status. Must be new, contacted, pending, completed, or cancelled." });
      }
      const enquiries = db.get("enquiries");
      const index = enquiries.findIndex((e) => e.id === id || e.inquiryId === id);
      if (index === -1) {
        return res.status(404).json({ error: "Inquiry not found" });
      }
      enquiries[index].status = status;
      enquiries[index].updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      db.set("enquiries", enquiries);
      if (serverSupabase) {
        try {
          const updatePayload = { status, updated_at: enquiries[index].updatedAt };
          await Promise.allSettled([
            serverSupabase.from("reveg_inquiries").update(updatePayload).or(`id.eq.${id},inquiry_id.eq.${id}`),
            serverSupabase.from("inquiries").update(updatePayload).or(`id.eq.${id},inquiry_id.eq.${id}`)
          ]);
        } catch (supaErr) {
          console.warn("Supabase status update warning:", supaErr);
        }
      }
      return res.json({ success: true, inquiry: enquiries[index] });
    } catch (err) {
      console.error("Error updating inquiry status:", err);
      return res.status(500).json({ error: "Failed to update inquiry status" });
    }
  };
  app.patch("/api/inquiries/:id/status", requireAuth, handleUpdateStatus);
  app.patch("/api/inquiries/:id", requireAuth, handleUpdateStatus);
  app.patch("/api/enquiries/:id", requireAuth, handleUpdateStatus);
  const handleDeleteInquiry = async (req, res) => {
    try {
      const { id } = req.params;
      const enquiries = db.get("enquiries");
      const filtered = enquiries.filter((e) => e.id !== id && e.inquiryId !== id);
      db.set("enquiries", filtered);
      if (serverSupabase) {
        try {
          await Promise.allSettled([
            serverSupabase.from("reveg_inquiries").delete().or(`id.eq.${id},inquiry_id.eq.${id}`),
            serverSupabase.from("inquiries").delete().or(`id.eq.${id},inquiry_id.eq.${id}`)
          ]);
        } catch (supaErr) {
          console.warn("Supabase delete warning:", supaErr);
        }
      }
      return res.json({ success: true, message: "Inquiry deleted successfully" });
    } catch (err) {
      console.error("Error deleting inquiry:", err);
      return res.status(500).json({ error: "Failed to delete inquiry" });
    }
  };
  app.delete("/api/inquiries/:id", requireAuth, handleDeleteInquiry);
  app.delete("/api/enquiries/:id", requireAuth, handleDeleteInquiry);
  app.get("/api/navigation", (req, res) => {
    return res.json(db.get("navigation"));
  });
  app.put("/api/navigation", requireAuth, (req, res) => {
    db.set("navigation", req.body);
    return res.json({ success: true, navigation: req.body });
  });
  app.get("/api/footer", (req, res) => {
    return res.json(db.get("footer"));
  });
  app.put("/api/footer", requireAuth, (req, res) => {
    db.set("footer", req.body);
    return res.json({ success: true, footer: req.body });
  });
  app.get("/api/media", requireAuth, (req, res) => {
    return res.json(db.get("media"));
  });
  app.post("/api/media/upload", requireAuth, upload.single("image"), (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: "No image file uploaded" });
    }
    const fileUrl = `/uploads/${req.file.filename}`;
    const mediaItem = {
      id: "med_" + Date.now(),
      name: req.body.name || req.file.originalname,
      originalName: req.file.originalname,
      url: fileUrl,
      mimeType: req.file.mimetype,
      size: req.file.size,
      uploadedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    const media = db.get("media");
    media.unshift(mediaItem);
    db.set("media", media);
    return res.json({ success: true, media: mediaItem });
  });
  app.post("/api/media/upload-base64", requireAuth, (req, res) => {
    const { base64Data, filename, name } = req.body;
    if (!base64Data) {
      return res.status(400).json({ error: "Base64 data required" });
    }
    try {
      const matches = base64Data.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
      if (!matches || matches.length !== 3) {
        return res.status(400).json({ error: "Invalid base64 image data" });
      }
      const mimeType = matches[1];
      const buffer = Buffer.from(matches[2], "base64");
      const ext = mimeType.split("/")[1] || "jpg";
      const cleanName = (filename || "image").replace(/[^a-zA-Z0-9_-]/g, "_");
      const outFilename = `${cleanName}-${Date.now()}.${ext}`;
      const filePath = import_path2.default.join(UPLOADS_DIR, outFilename);
      import_fs2.default.writeFileSync(filePath, buffer);
      const fileUrl = `/uploads/${outFilename}`;
      const mediaItem = {
        id: "med_" + Date.now(),
        name: name || filename || outFilename,
        originalName: filename || outFilename,
        url: fileUrl,
        mimeType,
        size: buffer.length,
        uploadedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      const media = db.get("media");
      media.unshift(mediaItem);
      db.set("media", media);
      return res.json({ success: true, media: mediaItem });
    } catch (err) {
      console.error("Failed to save base64 image", err);
      return res.status(500).json({ error: "Failed to process base64 upload" });
    }
  });
  app.delete("/api/media/:id", requireAuth, (req, res) => {
    const { id } = req.params;
    const media = db.get("media");
    const target = media.find((m) => m.id === id);
    if (target && target.url.startsWith("/uploads/")) {
      const diskPath = import_path2.default.join(process.cwd(), "public", target.url);
      if (import_fs2.default.existsSync(diskPath)) {
        try {
          import_fs2.default.unlinkSync(diskPath);
        } catch (e) {
          console.error("Failed to unlink file:", e);
        }
      }
    }
    const updatedMedia = media.filter((m) => m.id !== id);
    db.set("media", updatedMedia);
    return res.json({ success: true, message: "Media item removed" });
  });
  app.post("/api/reset-demo", requireAuth, (req, res) => {
    const freshDb = db.resetToDefaults();
    return res.json({ success: true, message: "Database reset to authentic RevEg demo state", db: freshDb });
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path2.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path2.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[RevEg Server] Server running on http://localhost:${PORT}`);
  });
}
startServer().catch((err) => {
  console.error("[RevEg Server] Fatal startup error:", err);
});
//# sourceMappingURL=server.cjs.map
